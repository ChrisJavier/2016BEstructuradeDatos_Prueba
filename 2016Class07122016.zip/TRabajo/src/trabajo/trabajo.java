package trabajo;

import java.util.Scanner;

public class trabajo {
	
	
public static void main(String args[])
{
	long time_start, time_end;
	time_start= System.currentTimeMillis();
	
	
/*	int aux = 0;
	int valorFib1=0;
	int valorFib2=1;
	Scanner in=new Scanner(System.in);
	int finalFib=0;
	
	System.out.print("Ingrese la cantidad de terminos: ");
	finalFib=in.nextInt();
	
	for(int i =0;i<=finalFib;i++)
	{
		System.out.print("\nPosicion "+i+" = "+ fibonacci(i));
		
		
		aux=valorFib2;
		valorFib2+=valorFib1;
		valorFib1=aux;
		aux=0;
				
		
	}
	time_end= System.currentTimeMillis();*/
	/*System.out.println("THE TASK HAS TAKEN " + (time_end-time_start)+" MILLISECONDS");*/
	int n=5;
	System.out.println(fibonacci(n));
}

public static double  fibonacci(long n)
{
		if (n <= 1)
			return n; 
		else return fibonacci(n-1) + fibonacci(n-2); 

}
static int invertir (int n)
{

if (n < 10)         //caso base
   return n;
else
   return (int) ((n % 10)*(Math.pow(10,String.valueOf(n).length()-1)) + invertir (n / 10)) ;
}
}
