
public abstract class FiguraGeometrica {

	
	
	public abstract  double CalcularArea(Punto pta, Punto ptb, Punto ptc, Punto ptd, int Indicador);
	
	public abstract  double CalcularArea(Punto pta, double rad);

	
	public abstract  double CalcularArea(Punto pta, Punto ptb, Punto ptc, int Indicador);
}
